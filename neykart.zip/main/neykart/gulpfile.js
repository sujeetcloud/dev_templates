/*!
  Template Name: Neykart: E-commerce HTML Template by @devjey_io
	Version: 1.0
	Author: DevJEY
 */

const fileinclude = require("gulp-file-include");
const { src, dest, watch, series } = require("gulp");
const babel = require("gulp-babel");
const minifyJSFiles = require("gulp-uglify");
const sourceMaps = require("gulp-sourcemaps");
const concat = require("gulp-concat");
const postcss = require("gulp-postcss");
const tailwindcss = require("tailwindcss");
const cssnano = require("cssnano");

/**  Create a function to Concatenates all CSS Plugins into one bundle.plugins.css file - Start */

/**  Files Paths & TailwindCSS - Start */
const PATHS = {
  config: "./tailwind.config.js",
  dist: {
    dir: "./public/",
    files: "./public/**/*",
    css: "./public/assets/global/css/",
    js: "./public/assets/global/js/",
    plugins: {
      css: "./public/assets/global/css/plugins",
      js: "./public/assets/global/js/plugins",
    },
  },
  src: {
    base: {
      dir: "./",
      files: "./src/**/*",
    },
    html: {
      dir: "./src",
      files: "./src/**/*.html",
    },
    statics: {
      dir: "./src/assets",
      files: "./src/statics/**/*",
    },
    css: {
      dir: "./src/assets",
      files: "./src/assets/**/*.css",
      tailwind: "./src/assets/css/style.css",
    },
    js: {
      dir: "./src/assets",
      files: "./src/assets/**/*.js",
    },
  },
};

const tailwindTask = () => {
  return src(PATHS.src.css.tailwind)
    .pipe(sourceMaps.init({ largeFile: true }))
    .pipe(
      postcss([
        require("postcss-import"),
        require("tailwindcss/nesting"),
        tailwindcss(PATHS.config),
        require("autoprefixer"),
        cssnano(),
      ])
    )
    .pipe(concat("theme.min.css"))
    .pipe(sourceMaps.write("./"))
    .pipe(dest(PATHS.dist.css));
};
/**  Files Paths & TailwindCSS - End */

const allCSSPlugins = () => {
  return src([
    "./src/assets/css/plugins/swiper-bundle.min.css",
    "./src/assets/fontawesome/css/all.min.css",
    "./src/assets/css/plugins/animate.min.css",
  ])
    .pipe(concat("bundle.plugins.css"))
    .pipe(dest(PATHS.dist.plugins.css));
};

allCSSPlugins();
/**  Create a function to Concatenates all CSS Plugins into one bundle.plugins.css file - End */

/** Gulp Includes function - Start */

async function includeHTML() {
  return src([
    PATHS.src.html.files,
    "!" + PATHS.dist.files, // ignore
    "!" + PATHS.src.statics.files, // ignore
  ])
    .pipe(
      fileinclude({
        prefix: "@@",
        basepath: "@file",
        indent: true,
      })
    )
    .pipe(dest(PATHS.dist.dir));
}

/** Gulp Includes function - End */

/**  Create a function to Minify, Concatenates all js Plugins into one bundle.plugins.js file - Start */

const allJSPlugins = () => {
  return (
    src([
      "./src/assets/js/plugins/swiper-bundle.min.js",
      "./src/assets/fontawesome/js/all.min.js",
      "./src/assets/js/plugins/popper.js",
      "./src/assets/js/plugins/purify.js",
    ])
      // Transpile the JS code using Babel's preset-env.
      .pipe(
        babel({
          presets: ["@babel/preset-env"],
        })
      )
      .pipe(minifyJSFiles())
      .pipe(concat("bundle.plugins.js"))
      .pipe(dest(PATHS.dist.plugins.js))
  );
};

allJSPlugins();
/**  Create a function to Minify, Concatenates all js Plugins into one bundle.plugins.js file - End */

/**  Create a function to Minify, Concatenates .js file from ./src folder into one .js file - Start */

const allJSFiles = () => {
  return (
    src([
      "./src/assets/js/app.js",
      "./src/assets/js/home.js",
      "./src/assets/js/all-swiper.js",
      "./src/assets/js/countdown-time.js",
      "./src/assets/js/all-elements.js",
    ])
      // Transpile the JS code using Babel's preset-env.
      .pipe(
        babel({
          presets: ["@babel/preset-env"],
        })
      )
      .pipe(sourceMaps.init({ largeFile: true }))
      .pipe(minifyJSFiles())
      .pipe(concat("main.min.js"))
      .pipe(sourceMaps.write("./"))
      .pipe(dest(PATHS.dist.js))
  );
};

/** Create a function to Minify, Concatenates .js file from ./src folder into one .js file - End */

/** Watch Changes for all .js files from ./src folder - Start */

const watchChanges = () => {
  watch([PATHS.config, PATHS.src.base.files], series(tailwindTask, includeHTML, allJSFiles));
};

/** Watch Changes for all .js files from ./src folder - Start */

/** Export JS Files - Start */

exports.watchChanges = watchChanges;

/** Export JS Files - End */
