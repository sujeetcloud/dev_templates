/*!
  Template Name: Neykart: E-commerce HTML Template by @devjey_io
	Version: 1.0
	Author: DevJEY
 */

const defaultTheme = require("tailwindcss/defaultTheme");

/** ===== Custom Variable CSS Function == Start */
function withOpacity(variableName) {
  return ({ opacityValue }) => {
    if (opacityValue !== undefined) {
      return `rgba(var(${variableName}), ${opacityValue})`;
    }
    return `rgb(var(${variableName}))`;
  };
}
/** ===== Custom Variable CSS Function == End */

module.exports = {
  content: ["./src/**/*.html", "./assets/src/css/**/*.{html,js}", "./src/assets/js/**/*.{html,js}"],

  // safelist: ["example-class"], ====== Use this for dynamic unused class
  theme: {
    /** ===== XS Screen & Defaults Screens == Start */
    screens: {
      xs: "420px",
      ...defaultTheme.screens,
    },
    /** ===== XS Screen & Defaults Screens == End */
    /** ===== Custom & Default Font Family == Start */
    fontFamily: {
      sans: ["Nunito", ...defaultTheme.fontFamily.sans],
      // serif: [...defaultTheme.fontFamily.serif],
      // mono: [...defaultTheme.fontFamily.mono],
    },
    /** ===== Custom & Default Font Family == End */
    extend: {
      /** ===== Hero Background Image == Start */
      backgroundImage: {
        hero: "url('../../../assets/img/main-hero.jpg')",
      },
      /** ===== Hero Background Image == End */
      /** ===== Custom Variable CSS == Start */
      colors: {
        primary: withOpacity("--nk-primary"),
        "primary-100": withOpacity("--nk-primary-100"),
        "primary-200": withOpacity("--nk-primary-200"),
        "primary-300": withOpacity("--nk-primary-300"),
        "primary-400": withOpacity("--nk-primary-400"),
        "primary-500": withOpacity("--nk-primary-500"),
        "primary-600": withOpacity("--nk-primary-600"),
        "primary-800": withOpacity("--nk-primary-800"),
        secondary: withOpacity("--nk-secondary"),
        accent: withOpacity("--nk-accent"),
        success: withOpacity("--nk-success"),
        info: withOpacity("--nk-info"),
        warning: withOpacity("--nk-warning"),
        danger: withOpacity("--nk-danger"),
        light: withOpacity("--nk-light"),
      },
      /** ===== Custom Variable CSS == End */
      /** ===== Transform Origin == Start */
      transformOrigin: {
        0: "0%",
      },
      /** ===== Transform Origin == End */
      /** ===== Fill == Start */
      fill: {
        current: "currentColor",
      },
      /** ===== Fill == Ends */
      /** ===== Keyframes == Start */
      keyframes: {
        slide: {
          "0%": {
            "-webkit-transform": "translate(0, 100%)",
            transform: "translate(0, 100%)",
          },
          "100%": {
            "-webkit-transform": "translate(0, -100%)",
            transform: "translate(0, -100%)",
          },
        },
      },
      animation: {
        "nk-slide": "slide 2.5s linear infinite",
      },
    },
    /** ===== Keyframes == Ends */
  },
  /** ===== All Plugins == Starts */
  plugins: [require("@tailwindcss/line-clamp"), require("@tailwindcss/forms")],
  /** ===== All Plugins == Ends */
};
