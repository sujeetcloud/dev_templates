/*!
  Template Name: Neykart: E-commerce HTML Template by @devjey_io
	Version: 1.0
	Author: DevJEY
 */
"use strict";

// Set the date we're counting down to
let countDownDate = new Date("May 31, 2023 23:59:59").getTime();
let today_count_time = new Date("May 31, 2023 23:59:59").getTime();
// today_count_time = new Date().getTime();

// Update the count down every 1 second
let time = setInterval(() => {
  // Get today's date and time
  let todayDeal = new Date().getTime();
  let today_top_deal = new Date().getTime();

  // Find the distance between now and the count down date
  let expiryTime = countDownDate - todayDeal;
  let today_expiry_time = today_count_time - today_top_deal;

  // Time calculations for days, hours, minutes and seconds
  let days = Math.floor(expiryTime / (1000 * 60 * 60 * 24));
  let hours = Math.floor((expiryTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  let minutes = Math.floor((expiryTime % (1000 * 60 * 60)) / (1000 * 60));
  let seconds = Math.floor((expiryTime % (1000 * 60)) / 1000);

  // Time calculations for days, hours, minutes and seconds
  let t_days = Math.floor(today_expiry_time / (1000 * 60 * 60 * 24));
  let t_hours = Math.floor((today_expiry_time % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  let t_minutes = Math.floor((today_expiry_time % (1000 * 60 * 60)) / (1000 * 60));
  let t_seconds = Math.floor((today_expiry_time % (1000 * 60)) / 1000);

  // Today Top Deals Timer - Start
  let today_time_count = document.getElementById("today-grocery-deal");

  if (today_time_count !== null) {
    today_time_count.innerHTML = DOMPurify.sanitize(`
        <div><span>${t_days}</span><span>D</span></div>
        <div><span>${t_hours}</span><span>H</span></div>
        <div><span>${t_minutes}</span><span>M</span></div>
        <div><span>${t_seconds}</span><span>S</span></div>
    `);
  }
  // Today Top Deals Timer - End

  // Single Product Timer - Start
  let timeCount = document.getElementById("dealOfDays");

  if (timeCount !== null) {
    timeCount.innerHTML = DOMPurify.sanitize(`
                <div class="w-full">
                  <div class="flex flex-col justify-center space-y-9">
                    <div class="flex space-x-2 sm:flex-row sm:flex-nowrap sm:space-x-6">
                      <div
                        class="border-primary bg-primary-100 flex w-16 flex-col items-center justify-center space-y-1 rounded border-2 p-1 uppercase shadow-lg"
                      >
                        <div class="border-primary border-b text-lg font-semibold sm:text-xl">
                          <span class="from-primary-600 bg-gradient-to-r to-pink-500 bg-clip-text text-transparent"
                            >${days}</span
                          >
                        </div>
                        <div class="text-primary text-xs font-medium">Days</div>
                      </div>
                      <div
                        class="border-primary bg-primary-100 flex w-16 flex-col items-center justify-center space-y-1 rounded border-2 p-1 uppercase shadow-lg"
                      >
                        <p class="border-primary border-b text-lg font-semibold sm:text-xl">
                          <span class="from-primary-600 bg-gradient-to-r to-pink-500 bg-clip-text text-transparent"
                            >${hours}</span
                          >
                        </p>
                        <p class="text-primary text-xs font-medium">Hours</p>
                      </div>
                      <div
                        class="border-primary bg-primary-100 flex w-16 flex-col items-center justify-center space-y-1 rounded border-2 p-1 uppercase shadow-lg"
                      >
                        <p class="border-primary border-b text-lg font-semibold sm:text-xl">
                          <span class="from-primary-600 bg-gradient-to-r to-pink-500 bg-clip-text text-transparent"
                            >${minutes}</span
                          >
                        </p>
                        <p class="text-primary text-xs font-medium">Minutes</p>
                      </div>
                      <div
                        class="border-primary bg-primary-100 flex w-16 flex-col items-center justify-center space-y-1 rounded border-2 p-1 uppercase shadow-lg"
                      >
                        <p class="border-primary border-b text-lg font-semibold sm:text-xl">
                          <span class="from-primary-600 bg-gradient-to-r to-pink-500 bg-clip-text text-transparent"
                            >${seconds}</span
                          >
                        </p>
                        <p class="text-primary text-xs font-medium">Seconds</p>
                      </div>
                    </div>
                  </div>
                </div>
          `);

    // Count Down Expiry
    if (expiryTime < 0) {
      clearInterval(time);
      document.getElementById("dealOfDay").innerHTML = DOMPurify.sanitize("EXPIRED");
    }
  }
  // Single Product Timer - Start
}, 1000);
