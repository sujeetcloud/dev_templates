/*!
  Template Name: Neykart: E-commerce HTML Template by @devjey_io
	Version: 1.0
	Author: DevJEY
 */
/*--------------------------------------------------------------
>>> TABLE OF CONTENTS:
----------------------------------------------------------------
1. Customer Trust
2. Brands
-------------------------------------------------------------- */

"use strict";

// FETCH LOCAL .JSON DATA
const allCustomerTrust = fetch("./assets/data/home/customerTrust.json");
const allbrands = fetch("./assets/data/home/brands.json");

Promise.all([allCustomerTrust, allbrands])
  .then((values) => {
    return Promise.all(values.map((r) => r.json()));
  })
  .then(([allCustomerTrust, brands]) => {
    //console.log(allCustomerTrust);
    //console.log(brands);

    /** 1. Customer Trust Section - Start */
    let cTrust = document.getElementById("customerTrust");

    if (cTrust !== null) {
      cTrust.innerHTML = DOMPurify.sanitize(`
          ${allCustomerTrust
            .map((customerTrust) => {
              return `
              <div class="W-1/4 xl:w-1/4 flex-grow flex-shrink-0 md:flex-shrink md:flex-grow-0">
                <div class="text-sm flex lg:flex-row space-x-3 lg:items-center">
                  <span class="block lg:inline-block text-3xl text-primary">
                    ${customerTrust.trustSvg}
                  </span>
                  <span class="whitespace-nowrap">
                    <h1 class="lg:text-sm font-semibold text-gray-900">${customerTrust.trustHead}</h1>
                    <p class="text-sm text-gray-500">${customerTrust.trustDetail}</p>
                  </span>
                </div>              
              </div>
            `;
            })
            .join("")}
        `);
    }
    /** 1. Customer Trust Section - End */

    /** 2. Brands Section - Start */
    let brandList = document.querySelector(".brands");

    if (brandList !== null) {
      brandList.innerHTML = DOMPurify.sanitize(`
       ${brands
         .map((brands) => {
           return `
              <div class="w-28">
                <div class="px-3 py-2 h-10 w-28 border border-gray-600 rounded-sm bg-white cursor-pointer transform duration-300 ease-in-out hover:-translate-y-1 hover:shadow-lg">
                    <a href="${brands.brandURL}">
                        <img class="h-full w-full object-center" src="${brands.brandSvg}" alt="" />
                    </a>
                </div>
              </div>
            `;
         })
         .join("")}
      `);
    }
    /** 2. Brands Section - End */

    //document.getElementById("").innerHTML = DOMPurify.sanitize(``);

    // END CURL BRACES
  });
