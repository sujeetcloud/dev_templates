/** -- Check if Date is Valid -- */
const isDateValid = (...val) => !Number.isNaN(new Date(...val).valueOf());
isDateValid("October 17, 2021 03:24:00");
//result: true

/** -- Find the Day of the Year -- */
const dayOfYear = (date) => Math.floor((date = new Date(date.getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24);

/** -- Copy to Clipboard -- */
const copyToClipboard = (text) => navigator.clipboard.writeText(text);
copyToClipboard("Hello World");

/** -- Clear All Cookies -- */
const clearCookies = document.cookie
  .split(";")
  .forEach(
    (cookie) =>
      (document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, ` = ;express=${new Date(0).toUTCString()};path=/`))
  );

/** -- Generate random Hex -- */
const randomHex = () =>
  `#${Math.floor(Math.random() * 0xffffff)
    .toString(16)
    .padEnd(6, "0")}`;
console.log(randomHex);
