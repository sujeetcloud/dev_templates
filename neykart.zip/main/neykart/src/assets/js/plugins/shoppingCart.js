/* Get data from LocalStorage in Browser  */
let productsInCart = JSON.parse(localStorage.getItem("ShoppingCart"));

/* Check if there is product in the Cart to remove Error */
if (!productsInCart) {
  productsInCart = [];
}

/* Empty Cart */
const parentElement = document.querySelector("#buyItems"); /* parentDiv -- CART: id=shoppingCartMenu */
const parentCartDiv = document.querySelector("#shoppingCartMenu"); /* Ecoxify */
const cartSumPrice = document.querySelector("#sum-prices"); /* select SUM prices == Items total count ID */
const totalItems = document.querySelector("#cartItemCount"); /* Ecoxify */
/* Select all products with class .product-under in the pages that have add to cart button  */
const products = document.querySelectorAll(".product-under"); /* Which is the Div of single product */
const products = document.querySelectorAll(".productBtn"); /* Ecoxify */

/* Call a function for updating Price */
//const countTotalItem = function() { /* Ecoxify */
const countTheSumPrice = function () {
  let sumPrice = 0;
  //let totalItems = 0; /* Ecoxify */
  /* Loop through the products in Cart list and update some price in product each product */
  productsInCart.forEach((product) => {
    /* Update some price by product price */
    sumPrice += product.price;
    //totalItems = productsInCart.length; /* Ecoxify */
  });
  return sumPrice;
  //return totalItems; /* Ecoxify */
};

/* will check if there is product in ProductsInCart -- 
Then it will loop through and generate html ,
if there is nothing in the Cart will hide the checkout button and add some text like 
-- There is nothing in your Cart */
const updateShoppingCartHTML = function () {
  /* to use localStorage using key value (ShoppingCart) pair */
  localStorage.setItem("ShoppingCart", JSON.stringify(productsInCart));
  if (productsInCart.length > 0) {
    let result = productsInCart.map((product) => {
      /* Return a String some output*/
      return `
				<!-- HTML Code for the Product in Cart "ID=shoppingCartMenu" -->
				<li class='buyItem'> 
					<img src="${product.image}" alt="">
					<div>
						<h5>${product.name}</h5>
						<h6>${product.price}</h6>
						<div>
							<button class="button-minus" data-id="${product.id}">-</button>
							<span class="countOfProduct">${product.count}</span>
							<button class="button-plus" data-id="${product.id}">+</button>
						</div>
					</div>
				</li>
			`;
    });
    /* Set parent Element  */
    parentElement.innerHTML = result.join("");

    /* Remove hidden className from classList of checkout button if not empty */
    document.querySelector(".checkout").classList.remove("hidden");
    //document.getElementById("itemsCart").style.display = "block"; /* Ecoxify */
    //document.getElementById("itemsCart").style.opacity = 1; /* Ecoxify */

    /* update some prices  */
    cartSumPrice.innerHTML = "$" + countTheSumPrice(); /* call a function -- : -- use .length property */
    //totalItems.innerHTML = countTotalItem(); /* Ecoxify */
  } else {
    /* if shopping cart is empty will remove the checkout button by using class name */
    document.querySelector(".checkout").classList.add("hidden");
    //document.getElementById("emptyCart").style.display = "none"; /* Ecoxify */
    /* add text to the parent element -- : -- id=emptyCart*/
    parentElement.innerHTML = '<h4 class"">Your shopping cart is empty</h4>';
    /* Set some price in cart Nav menu / Remove  */
    cartSumPrice.innerHTML = "";
    //totalItems.innerHTML = "0"; /* Ecoxify */
  }
};

/* Create a function - Update cart list -- Loop products in the list  -- and check if product exist 
-- if it does we able to increase count and add 1 , and if it doesn't will item to add to cart */
function updateProductsInCart(product) {
  for (let i = 0; i < productsInCart.length; i++) {
    /* Check if product ID hat we pass is equal to product index it is  */
    if (productsInCart[i].id == product.id) {
      /* and if they are same increase count by 1 */
      productsInCart[i].count += 1;
      /* for the price */
      productsInCart[i].price = productsInCart[i].basePrice * productsInCart[i].count;
      return; /* exit */
    }
  }
  /* if loop through and dont find the product in cart that have the same id, 
	then means product does not exit in the list and add the product to list by using push()*/
  productsInCart.push(product);
}

/* Add Event Listener those products */
products.forEach((product) => {
  product.addEventListener("click", (e) => {
    if (e.target.classList.contains("addToCart")) {
      /* Grab product information add to cart by using product id, access data id (data-product-id="1") */
      const productID = e.target.dataset.productId;

      /* Get product name by using className */
      const productName = product.querySelector(".productName").innerHTML;
      /* Get price name by using className */
      const productPrice = product.querySelector(".priceValue").innerHTML;
      /* Get Image name by using className */
      const productImg = product.querySelector("img").src;
      /* Set all information above into an object By create object  */
      let productToCart = {
        name: productName,
        image: productImg,
        id: productID,
        count: 1,
        price: +productPrice,
        /* We need basePrice because price will change each time count is changed */
        basePrice: +productPrice,
      };
      /* Call functions */
      updateProductsInCart(productToCart); /* will update item in cart */
      updateShoppingCartHTML(); /* Will update HTML Code */
    }
  });
});

/* Plus + Minus by add Event Listener to the parent element and check if come from one of the those button (-,+) */
parentElement.addEventListener("click", (e) => {
  const isPlusButton = e.target.classList.contains("button-plus");
  const isMinusButton = e.target.classList.contains("button-minus");

  if (isPlusButton || isMinusButton) {
    for (let i = 0; i < productsInCart.length; i++) {
      /* Check if product in cart with index with id is same as event target  */
      if (productsInCart[i].id === e.target.dataset.id) {
        /* Check which button is clicked  */
        if (isPlusButton) {
          productsInCart[i].count += 1;
        } else if (isPlusButton) {
          productsInCart[i].count -= 1;
        }
        /* Update the price if the count is changed  */
        productsInCart[i].price = productsInCart[i].basePrice * productsInCart[i].count;
      }
      /* Check if the count is 0 we have to remove in the cart  */
      if (productsInCart[i].count <= 0) {
        productsInCart.splice(i, 1);
      }
    }
    /* Change/Update HTML code  */
    updateShoppingCartHTML();
  }
});

updateShoppingCartHTML();
